#ifndef __NDITER_PYWRAP_H
#define __NDITER_PYWRAP_H

NPY_NO_EXPORT PyObject *
NpyIter_NestedIters(PyObject *NPY_UNUSED(self),
                    PyObject *args, PyObject *kwds);

#endif
