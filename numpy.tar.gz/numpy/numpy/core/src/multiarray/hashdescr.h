#ifndef _NPY_HASHDESCR_H_
#define _NPY_HASHDESCR_H_

NPY_NO_EXPORT npy_hash_t
PyArray_DescrHash(PyObject* odescr);

#endif
